const express = require('express');
const fs = require('fs');
const path = require('path');
const Stripe = require('stripe');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const stripeSecret = process.env.STRIPE_SECRET_KEY || '';
const stripe = stripeSecret ? new Stripe(stripeSecret) : null;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/admin', express.static(path.join(__dirname, 'admin')));

function ensureDataFile() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]', 'utf8');
}

function readOrders() {
  ensureDataFile();
  try {
    const raw = fs.readFileSync(ORDERS_FILE, 'utf8');
    return JSON.parse(raw || '[]');
  } catch (error) {
    return [];
  }
}

function saveOrders(orders) {
  ensureDataFile();
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2), 'utf8');
}

function calculateQuote({ quantity, deliveryType, designNeeded, printBundles }) {
  const qty = Number(quantity) || 0;
  const distributionBasePer1k = deliveryType === 'shared' ? 39 : 55;
  const printPer1k = 28;
  const designFee = designNeeded ? 95 : 0;
  const printCost = (Number(printBundles) || 0) * printPer1k;
  const distributionCost = (qty / 1000) * distributionBasePer1k;
  const subtotal = distributionCost + printCost + designFee;
  return {
    subtotal: Number(subtotal.toFixed(2)),
    distributionCost: Number(distributionCost.toFixed(2)),
    printCost: Number(printCost.toFixed(2)),
    designFee: Number(designFee.toFixed(2))
  };
}

app.get('/api/config', (req, res) => {
  res.json({
    stripePublicKey: process.env.STRIPE_PUBLIC_KEY || '',
    businessEmail: process.env.BUSINESS_EMAIL || 'info@leafletprouk.com',
    businessPhone: process.env.BUSINESS_PHONE || '020 8103 5100'
  });
});

app.post('/api/quote', (req, res) => {
  const quote = calculateQuote(req.body || {});
  res.json(quote);
});

app.get('/api/orders', (req, res) => {
  const orders = readOrders().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(orders);
});

app.post('/api/orders', (req, res) => {
  const body = req.body || {};
  const orders = readOrders();
  const quote = calculateQuote(body);
  const order = {
    id: `LP-${Date.now()}`,
    createdAt: new Date().toISOString(),
    status: 'New',
    paymentStatus: 'Pending',
    customerName: body.customerName || '',
    email: body.email || '',
    phone: body.phone || '',
    postcode: body.postcode || '',
    quantity: Number(body.quantity) || 0,
    deliveryType: body.deliveryType || 'solus',
    designNeeded: Boolean(body.designNeeded),
    printBundles: Number(body.printBundles) || 0,
    notes: body.notes || '',
    ...quote
  };
  orders.push(order);
  saveOrders(orders);
  res.status(201).json(order);
});

app.patch('/api/orders/:id', (req, res) => {
  const orders = readOrders();
  const index = orders.findIndex((order) => order.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Order not found' });
  }
  orders[index] = { ...orders[index], ...req.body, updatedAt: new Date().toISOString() };
  saveOrders(orders);
  res.json(orders[index]);
});

app.post('/api/create-checkout-session', async (req, res) => {
  try {
    if (!stripe) {
      return res.status(400).json({ error: 'Stripe is not configured yet. Add STRIPE_SECRET_KEY and STRIPE_PUBLIC_KEY in your .env file.' });
    }
    const body = req.body || {};
    const quote = calculateQuote(body);
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'gbp',
          product_data: {
            name: 'Leaflet Distribution Order'
          },
          unit_amount: Math.round(quote.subtotal * 100)
        },
        quantity: 1
      }],
      customer_email: body.email || undefined,
      success_url: `${body.origin || 'http://localhost:' + PORT}/success.html`,
      cancel_url: `${body.origin || 'http://localhost:' + PORT}/cancel.html`
    });
    res.json({ url: session.url });
  } catch (error) {
    res.status(500).json({ error: error.message || 'Unable to create Stripe checkout session' });
  }
});

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/admin/')) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`LeafletPro Premium is running on http://localhost:${PORT}`);
});
