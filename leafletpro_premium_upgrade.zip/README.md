# LeafletPro Premium Starter

A premium starter site for leaflet distribution with:
- polished landing page
- postcode map targeting with Google Maps
- live quote calculator
- Stripe checkout starter
- order capture API
- admin dashboard
- JSON file storage starter

## Setup

1. Install dependencies
   npm install

2. Create `.env` from `.env.example`

3. Run
   npm start

4. Open
   http://localhost:3000
   Admin dashboard: http://localhost:3000/admin/

## Notes

- Replace `YOUR_GOOGLE_MAPS_API_KEY` in `public/index.html`
- Replace Stripe keys in `.env`
- Orders are stored in `data/orders.json`
- This is a strong starter kit and can be connected to a real database later
